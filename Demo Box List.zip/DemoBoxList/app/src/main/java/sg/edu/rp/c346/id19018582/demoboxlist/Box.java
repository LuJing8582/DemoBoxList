package sg.edu.rp.c346.id19018582.demoboxlist;

public class Box {
    private String colour;

    public Box(String colour) {
        this.colour = colour;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }
}
